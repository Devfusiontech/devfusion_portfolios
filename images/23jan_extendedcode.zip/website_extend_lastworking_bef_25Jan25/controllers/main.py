from odoo import _, http
from odoo import http, fields, tools, models
from odoo.http import request
import werkzeug
from odoo.addons.http_routing.models.ir_http import slug, unslug
from odoo.addons.website_blog.controllers.main import WebsiteBlog
from odoo.addons.website.controllers.main import QueryURL
from odoo.addons.website.controllers.main import Website
from odoo.addons.web.controllers.utils import _get_login_redirect_url
from odoo.addons.web.controllers.home import SIGN_UP_REQUEST_PARAMS
from odoo.addons.auth_signup.controllers.main import AuthSignupHome
from odoo.addons.auth_signup.models.res_users import SignupError
import json
import urllib.parse
from odoo.exceptions import UserError
import logging
_logger = logging.getLogger(__name__)

CUSTOM_SIGNUP_FIELDS = [
    "last_name",
    "availability",
#    "areaworkofinterest",
#    "skills",
    "past_work",
    "expectation"
]

CUSTOM_SIGNUP_BOOLEAN_FIELDS = [
    "confirmation",
    "signup_newsletter",
    "whatsapp_group",
    'health_promotion',
    'health_policy',
    'mental_health',
    'equity_diversity',
    'digital_transformation',
    'writing',
    'research',
    'public_affairs',
    'health_check_lifestyle',
    'design_digital_marketing',
    'project_coordination',
    'administration',
    'events_team',
    'community'
]

SIGN_UP_REQUEST_PARAMS.update(CUSTOM_SIGNUP_FIELDS)
SIGN_UP_REQUEST_PARAMS.update(CUSTOM_SIGNUP_BOOLEAN_FIELDS)


class AuthSignupHomeInherit(AuthSignupHome):
    
    def _prepare_signup_values(self, qcontext):
        values = super(AuthSignupHomeInherit,self)._prepare_signup_values(qcontext)
        values.update({ key: qcontext.get(key,False) for key in CUSTOM_SIGNUP_FIELDS })
        values.update({ key: True if qcontext.get(key,False) else False for key in CUSTOM_SIGNUP_BOOLEAN_FIELDS })
        print("--values--",values)
        print("--qcontext--",qcontext)
        return values
    
    @http.route('/web/volunteer/signup', type='http', auth='public', website=True, sitemap=False)
    def web_auth_volunteer_signup(self, *args, **kw):
        qcontext = self.get_auth_signup_qcontext()

        if not qcontext.get('token') and not qcontext.get('signup_enabled'):
            raise werkzeug.exceptions.NotFound()

        if 'error' not in qcontext and request.httprequest.method == 'POST':
            try:
                self.do_signup(qcontext)
                # Send an account creation confirmation email
                User = request.env['res.users']
                user_sudo = User.sudo().search(
                    User._get_login_domain(qcontext.get('login')), order=User._get_login_order(), limit=1
                )
                template = request.env.ref('auth_signup.mail_template_user_signup_account_created', raise_if_not_found=False)
                if user_sudo and template:
                    template.sudo().send_mail(user_sudo.id, force_send=True)
                return self.web_login(*args, **kw)
            except UserError as e:
                qcontext['error'] = e.args[0]
            except (SignupError, AssertionError) as e:
                if request.env["res.users"].sudo().search([("login", "=", qcontext.get("login"))]):
                    qcontext["error"] = _("Another user is already registered using this email address.")
                else:
                    _logger.warning("%s", e)
                    qcontext['error'] = _("Could not create a new account.") + "\n" + str(e)

        elif 'signup_email' in qcontext:
            user = request.env['res.users'].sudo().search([('email', '=', qcontext.get('signup_email')), ('state', '!=', 'new')], limit=1)
            if user:
                return request.redirect('/web/login?%s' % url_encode({'login': user.login, 'redirect': '/web'}))

        response = request.render('website_extend.signup_volunteer', qcontext)
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['Content-Security-Policy'] = "frame-ancestors 'self'"
        return response

class WebsiteInherit(Website):
    
    def _login_redirect(self, uid, redirect=None):
        return _get_login_redirect_url(uid, '/')

class WebsiteBlogInherit(WebsiteBlog):
    
    def _get_blog_post_search_options(self, blog=None, active_tags=None, date_begin=None, date_end=None, state=None, **post):
        result = super(WebsiteBlogInherit,self)._get_blog_post_search_options(blog=blog, active_tags=active_tags, date_begin=date_begin, date_end=date_end, state=state, **post)
        result['publication'] = post.get('publication',False)
        return result
    
    def _prepare_blog_values(self, blogs, blog=False, date_begin=False, date_end=False, tags=False, state=False, page=False, search=None, **post):
        values = super(WebsiteBlogInherit,self)._prepare_blog_values(blogs=blogs,blog=blog,date_begin=date_begin, date_end=date_end, tags=tags, state=state, page=page, search=search, **post)
        values['domain'] = values.get('domain',[]) + [('publication_blog','=',post.get('publication',False))]
        return values
    
    @http.route([
        '/publication',
        '/publication/page/<int:page>',
        '/publication/tag/<string:tag>',
        '/publication/tag/<string:tag>/page/<int:page>',
        '''/publication/<model("blog.blog"):blog>''',
        '''/publication/<model("blog.blog"):blog>/page/<int:page>''',
        '''/publication/<model("blog.blog"):blog>/tag/<string:tag>''',
        '''/publication/<model("blog.blog"):blog>/tag/<string:tag>/page/<int:page>''',
    ], type='http', auth="public", website=True, sitemap=True)
    def publication(self, blog=None, tag=None, page=1, search=None, **opt):
        opt['publication'] = True
        Blog = request.env['blog.blog']
        blogs = tools.lazy(lambda: Blog.search(request.website.website_domain() + [('publication_blog','=',opt.get('publication',False))], order="create_date asc, id asc"))

        date_begin, date_end = opt.get('date_begin'), opt.get('date_end')

        values = self._prepare_blog_values(blogs=blogs, blog=blog, tags=tag, page=page, search=search, **opt)
        # in case of a redirection need by `_prepare_blog_values` we follow it
        if isinstance(values, werkzeug.wrappers.Response):
            return values

        if blog:
            values['main_object'] = blog
        values['blog_url'] = QueryURL('/publication', ['blog', 'tag'], blog=blog, tag=tag, date_begin=date_begin, date_end=date_end, search=search)

        return request.render("website_extend.publication", values)
#        return request.render("website_extend.publication", values)
    
    def blog(self, blog=None, tag=None, page=1, search=None, **opt):
        opt['publication'] = False
        Blog = request.env['blog.blog']
        blogs = tools.lazy(lambda: Blog.search(request.website.website_domain() + [('publication_blog','=',opt.get('publication',False))], order="create_date asc, id asc"))

        if not blog and len(blogs) == 1:
            url = QueryURL('/blog/%s' % slug(blogs[0]), search=search, **opt)()
            return request.redirect(url, code=302)

        date_begin, date_end = opt.get('date_begin'), opt.get('date_end')

        if tag and request.httprequest.method == 'GET':
            # redirect get tag-1,tag-2 -> get tag-1
            tags = tag.split(',')
            if len(tags) > 1:
                url = QueryURL('' if blog else '/blog', ['blog', 'tag'], blog=blog, tag=tags[0], date_begin=date_begin, date_end=date_end, search=search)()
                return request.redirect(url, code=302)
        
        values = self._prepare_blog_values(blogs=blogs, blog=blog, tags=tag, page=page, search=search, **opt)
        # in case of a redirection need by `_prepare_blog_values` we follow it
        if isinstance(values, werkzeug.wrappers.Response):
            return values

        if blog:
            values['main_object'] = blog
        values['blog_url'] = QueryURL('/blog', ['blog', 'tag'], blog=blog, tag=tag, date_begin=date_begin, date_end=date_end, search=search)

        return request.render("website_blog.blog_post_short", values)
    
    @http.route([
        '''/blog/<model("blog.blog"):blog>/<model("blog.post", "[('blog_id','=',blog.id)]"):blog_post>''',
    ], type='http', auth="public", website=True, sitemap=True)
    def blog_post(self, blog, blog_post, tag_id=None, page=1, enable_editor=None, **post):
        """ Prepare all values to display the blog.

        :return dict values: values for the templates, containing

         - 'blog_post': browse of the current post
         - 'blog': browse of the current blog
         - 'blogs': list of browse records of blogs
         - 'tag': current tag, if tag_id in parameters
         - 'tags': all tags, for tag-based navigation
         - 'pager': a pager on the comments
         - 'nav_list': a dict [year][month] for archives navigation
         - 'next_post': next blog post, to direct the user towards the next interesting post
        """
        if blog_post.member_only and request.env.user._is_public():
            return request.redirect('/web/login?redirect=%s'%(urllib.parse.quote(request.httprequest._HTTPRequest__environ.get('PATH_INFO'))))
        return super(WebsiteBlogInherit,self).blog_post(blog=blog,blog_post=blog_post,tag_id=tag_id,page=page,enable_editor=enable_editor,**post)

