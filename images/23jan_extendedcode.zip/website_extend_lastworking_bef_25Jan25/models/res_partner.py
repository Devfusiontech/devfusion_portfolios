from odoo import api, models, fields, _

class PartnerOmherit(models.Model):
    _inherit = 'res.partner'
    
    last_name = fields.Char(string="Last Name")
    availability = fields.Char(string="Availability")
    areaworkofinterest = fields.Selection([
        ('health_promotion', 'Health promotion (cancer, cardiovascular, lifestyle, women’s health, other)'),
        ('health_policy', 'Health policy and research'),
        ('mental_health', 'Mental health and wellbeing'),
        ('equity_diversity', 'Equity, diversity and inclusion in the NHS·'),
        ('digital_transformation', 'Digital transformation and sustainability')
    ],string="Area Work of Intrest")
    skills = fields.Selection([
        ('writing', 'Writing (blogs/articles)'),
        ('research', 'Research'),
        ('public_affairs', 'Public affairs (media/advocacy)'),
        ('health_check_lifestyle', 'Health checks/lifestyle counselling'),
        ('design_digital_marketing', 'Design/digital marketing'),
        ('project_coordination', 'Project coordination'),
        ('administration', 'Administration'),
        ('events_team', 'Events team (online/in person)'),
        ('community', 'Community building and engagement')
    ],string="Skills")
    past_work = fields.Text(string="Please tell us about any work, volunteering, personal experience or skills that you have that are relevant to the role you are interested in")
    expectation = fields.Text(string="What do you hope to achieve with your volunteering experience?")
    confirmation = fields.Boolean(string="I confirm that the above information is true and accurate to the best of my knowledge")
    signup_newsletter = fields.Boolean(string="Sign up to our newsletter?")
    whatsapp_group = fields.Boolean(string="Would you be happy to be added to our volunteer WhatsApp group?")
    
    health_promotion = fields.Boolean(string="Health promotion (cancer, cardiovascular, lifestyle, women’s health, other)")
    health_policy = fields.Boolean(string="Health policy and research")
    mental_health = fields.Boolean(string="Mental health and wellbeing")
    equity_diversity = fields.Boolean(string="Equity, diversity and inclusion in the NHS")
    digital_transformation = fields.Boolean(string="Digital transformation and sustainability")
    writing = fields.Boolean(string="Writing (blogs/articles)")
    research = fields.Boolean(string="Research")
    public_affairs = fields.Boolean(string="Public affairs (media/advocacy)")
    health_check_lifestyle = fields.Boolean(string="Health checks/lifestyle counselling")
    design_digital_marketing = fields.Boolean(string="Design/digital marketing")
    project_coordination = fields.Boolean(string="Project coordination")
    administration = fields.Boolean(string="Administration")
    events_team = fields.Boolean(string="Events team (online/in person)")
    community = fields.Boolean(string="Community building and engagement")


