from . import blog_post
from . import res_partner
