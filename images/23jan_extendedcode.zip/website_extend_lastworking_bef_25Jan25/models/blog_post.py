from odoo import api, models, fields, _

class BlogBlog(models.Model):
    _inherit = 'blog.blog'
    
    publication_blog = fields.Boolean(string="Is Publication")

class BlogPost(models.Model):
    _inherit = 'blog.post'
    
    publication_blog = fields.Boolean(related="blog_id.publication_blog")
    member_only = fields.Boolean(string="Members Only",help="Available only for members")
    website_track_ids = fields.Many2many('website.track','rel_track_post','track_id','blog_post_id',compute="compute_blog_post",store=False)
    
    @api.depends('website_url')
    def compute_blog_post(self):
        for rec in self:
            rec.website_track_ids = [(6,0,self.env['website.track'].search([('url','ilike',rec.website_url)]).ids)]
    
    @api.model
    def _search_get_detail(self, website, order, options):
        result = super(BlogPost,self)._search_get_detail(website=website, order=order, options=options)
        result.get('base_domain').append([('publication_blog', '=', options.get('publication',False))])
        return result

    def _get_background_preprocess(self):
        image = self._get_background()
        return image[4:-1].strip('\'"')
