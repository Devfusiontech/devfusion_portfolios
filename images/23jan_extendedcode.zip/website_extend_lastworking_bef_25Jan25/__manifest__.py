# -*- coding: utf-8 -*-

{
    'name': 'WebsiteExtend',
    'version': '17.0.0.0',
    'category': '',
    "license": "OPL-1",
    'summary': ' ',
    'description': """   """,
    'depends': ['website','website_blog','auth_signup'],
    'data': [
        "views/blog_blog.xml",
        "views/blog_post.xml",
        "views/web_login.xml",
        "views/web_signup.xml",
        "views/website_blog_loop.xml",
        "views/publication_page.xml",
        "views/res_partner.xml",
        'views/portal.xml'
    ],
    'assets': {
        'web.assets_frontend':[
            'website_extend/static/src/css/website.css'
        ]
    },
    'application': False,
    'installable': True,
    'auto_install': False,
}
